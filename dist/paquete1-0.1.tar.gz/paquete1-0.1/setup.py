from setuptools import setup, find_packages

setup(
   name='paquete1',
    version='0.1',
   packages=find_packages(),
)

setup(
    name="paquete1",
    version="1.0",
    author="PazEzequiel",
    description="Primer paquete distribuido",
    author_email="ezequielivanpaz1@gmail.com",
    packages=["paquete"]
)