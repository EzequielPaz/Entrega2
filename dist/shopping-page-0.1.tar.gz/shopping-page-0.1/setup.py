from setuptools import setup, find_packages

setup(
   name='shopping-page',
    version='0.1',
   packages=find_packages(),
)

setup(
    name="paquete1",
    version="1.0",
    author="Clase 8 CODER - Python",
    description="Estamos haciendo el primer paquete distribuido",
    author_email="coder@coder.com",
    packages=["paquete"]
)